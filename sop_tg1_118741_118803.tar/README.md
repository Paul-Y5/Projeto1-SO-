# Projeto1 SO
Ferramenta de criação/atualização de cópias de segurança em bash
-----------------------------------------
Rafael Ferreira e Paulo Cunha [118803 118741]

Biblio:
https://stackabuse.com/get-total-size-of-a-directory-in-linux/

https://www.howtogeek.com/766978/how-to-use-case-statements-in-bash-scripts/

https://www.computerhope.com/unix/bash/shift.htm

https://blog.tratif.com/2023/01/09/bash-tips-1-logging-in-shell-scripts/

https://www.linuxforce.com.br/comandos-linux/comandos-linux-comando-getopts/

https://guialinux.uniriotec.br/

https://www.linuxjournal.com/content/pattern-matching-bash

Ideias retiradas de aulas práticas de SO: Arrays; funções; log; iterações(for); boas práticas;
